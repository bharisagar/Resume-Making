import 'package:flutter/material.dart' show BuildContext, InheritedWidget, Key, Widget, required;

import 'add_education_bloc.dart';

class AddEducationBlocProvider extends InheritedWidget {
  final AddEducationBloc bloc;

  const AddEducationBlocProvider({
    Key key,
    Widget child,
    @required this.bloc,
  }) : super(key: key, child: child);

  @override
  bool updateShouldNotify(_) => true;

  static AddEducationBloc of(BuildContext context) {
    return (context.dependOnInheritedWidgetOfExactType<AddEducationBlocProvider>()).bloc;
  }
}
