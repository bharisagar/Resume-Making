# resumepad

A new Flutter application for building resume.

## Screenshots
![Screenshot_2019-08-25-17-56-11-751_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653018-bdb7a980-c767-11e9-80ea-64952e88c5e0.png)
![Screenshot_2019-08-25-17-57-21-374_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653019-bdb7a980-c767-11e9-8701-3d80703c2f66.png)
![Screenshot_2019-08-25-17-57-26-357_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653020-bdb7a980-c767-11e9-9970-cfa8fdd70882.png)
![Screenshot_2019-08-25-17-58-07-800_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653021-be504000-c767-11e9-8969-f73bc60cede8.png)
![Screenshot_2019-08-25-17-58-19-684_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653022-be504000-c767-11e9-9ba9-12b1170e104f.png)
![Screenshot_2019-08-25-17-59-44-808_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653023-be504000-c767-11e9-9026-cd8f4b16e7a7.png)
![Screenshot_2019-08-25-18-07-45-859_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653024-be504000-c767-11e9-9ab3-ffdea11b3612.png)
![Screenshot_2019-08-25-18-08-16-211_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653025-bee8d680-c767-11e9-9e93-5de0bcb3641c.png)
![Screenshot_2019-08-25-18-09-31-751_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653026-bee8d680-c767-11e9-9e89-6e626bfe1506.png)
![Screenshot_2019-08-25-18-09-52-577_com mayandro resumepad](https://user-images.githubusercontent.com/16761273/63653028-bee8d680-c767-11e9-9cba-1172fdb2bb76.png)
